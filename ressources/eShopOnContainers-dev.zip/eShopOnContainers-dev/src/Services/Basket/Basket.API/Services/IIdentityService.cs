﻿namespace Microsoft.eShopOnContainers.Services.Basket.API.Services;

public interface IIdentityService
{
    string GetUserIdentity();
}

