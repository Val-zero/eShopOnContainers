# Containerized eShop - Catalog Service
Sample reference containerized application, cross-platform and microservices architecture.
Powered by Microsoft

Check procedures on how to get it started at the Wiki:
https://github.com/dotnet/eShopOnContainers/wiki



