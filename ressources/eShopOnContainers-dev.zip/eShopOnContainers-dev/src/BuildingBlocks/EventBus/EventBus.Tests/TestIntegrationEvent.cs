﻿using Microsoft.eShopOnContainers.BuildingBlocks.EventBus.Events;
using System;
using System.Collections.Generic;
using System.Text;

namespace EventBus.Tests
{
    public record TestIntegrationEvent : IntegrationEvent
    {
    }
}
